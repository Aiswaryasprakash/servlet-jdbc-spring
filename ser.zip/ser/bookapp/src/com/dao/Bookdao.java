package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bean.Book;
import com.mysql.cj.xdevapi.Statement;


public class Bookdao {

	public void saveBook(Book book) throws ClassNotFoundException, SQLException{
	try{
		String url="jdbc:mysql://localhost:3306/bookapp";
		String username="root";
		String password="Aspvpc@1";
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection(url,username,password);

	String qry="insert into book values(?,?,?)"	;
	PreparedStatement ps=con.prepareStatement(qry);
	ps.setInt(1, book.getId());
	ps.setString(2, book.getName());
	ps.setInt(3, book.getPrice());
	ps.executeUpdate();
	con.commit();
		}catch(SQLException e)
	{e.printStackTrace();}
	}
	public List<Book> getAllBook() throws ClassNotFoundException{
		List<Book> li=new ArrayList<Book>();
		try{
			String url="jdbc:mysql://localhost:3306/bookapp";
			String username="root";
			String password="Aspvpc@1";
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,username,password);

		
		PreparedStatement ps=con.prepareStatement("select * from book");
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			
			Book b=new Book();
			b.setId(rs.getInt(1));
			b.setName(rs.getString(2));
			b.setPrice(3);
			li.add(b);
		}}
		catch(SQLException e)
		{e.printStackTrace();
		}
		return li;
		
		
//		
//		public void delete(int id){
//			try{
//				String url="jdbc:mysql://localhost:3306/bookapp";
//				String username="root";
//				String password="Aspvpc@1";
//				Class.forName("com.mysql.cj.jdbc.Driver");
//				Connection con=DriverManager.getConnection(url,username,password);
//				String sql="delete from book where id=?";
//				PreparedStatement ps=con.prepareStatement(sql);
//				ps.setInt(1, id);
//				ps.executeUpdate();
//				con.commit();
//			
//			}catch(SQLException e){
//				e.printStackTrace();
//			}
//		}
		
		
		
		
		
		
	}
}
