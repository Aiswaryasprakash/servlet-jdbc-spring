package com.test;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Book;
import com.dao.Bookdao;

@WebServlet("/BookServlet")
public class BookServlet extends HttpServlet {
	
	Bookdao bd=null;
	
	
	private static final long serialVersionUID = 1L;
       
   
    public BookServlet() {
        super();
        bd=new Bookdao();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 
		int id=Integer.parseInt(request.getParameter("bid"));
		String name=request.getParameter("bname");
		int p=Integer.parseInt(request.getParameter("price"));
		Book book=new Book();
book.setId(id);
book.setName(name);
book.setPrice(p);
		try {
			bd.saveBook(book);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
