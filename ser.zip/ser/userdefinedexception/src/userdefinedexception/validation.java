package userdefinedexception;

public class validation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
check c=new check();
c.check(34);
	}

}
