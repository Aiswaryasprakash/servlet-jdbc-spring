package com.java8features;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.omg.Messaging.SyncScopeHelper;

public class colldemo {
	public static void main(String[] args) {
		
	
ArrayList<String> al=new ArrayList<String >();
al.add("jagd");
al.add("jagd");
al.add("wetag");
al.add("akhfkj");
//List<String> tokenlist=al.stream().collect(Collectors.toList());
//al.forEach(a->System.out.println(a));
//System.out.println(tokenlist);
//al.stream().filter(all->all.length()>5).forEach(System.out::println);
//al.stream().distinct().forEach(System.out::println);
//al.stream().filter((s)->s.startsWith("w")).forEach(System.out::println);
//al.stream().filter((s)->s.startsWith("w")).map(String::toUpperCase).forEach(System.out::println);
//al.stream().distinct().sorted().map(String::toUpperCase).forEach(System.out::println);
//al.stream().limit(3).forEach(System.out::println);
//al.stream().skip(2).forEach(System.out::println);
//if(al.stream().anyMatch((String s)->s.length()==2))
//{System.out.println("yes");}
//if(al.stream().allMatch((String s)->s.length()>3))
//{System.out.println("all are big names");}
if(al.stream().noneMatch((String s)->s.length()==4))
{System.out.println("there is no 3 letter");}
}
}