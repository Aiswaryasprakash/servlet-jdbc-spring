package com.java8features;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;

public class dateeg {
public static void main(String[] args) {
	LocalDate today=LocalDate.now();
	LocalDateTime t=LocalDateTime.now();
	ZonedDateTime zone=ZonedDateTime.now();
	LocalDate d=zone.toLocalDate();
	System.out.println(today.toString());
	System.out.println(t.getHour());
	System.out.println(zone);
	System.out.println(d);
}
}
