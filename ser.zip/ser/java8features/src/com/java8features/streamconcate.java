package com.java8features;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class streamconcate {
public static void main(String[] args) {
	List<String> alpha=Arrays.asList("a","c","b");
	List<String> names=Arrays.asList("sansa","jon","fora");
	Stream s1=alpha.stream();
	Stream<String> opstream=Stream.concat(s1,names.stream());
	opstream.forEach(str->System.out.print(str+" "));
	System.out.println();
	Stream<Integer>streamOfNumbers=Stream.of(7,2,6,9,4,3,1);
	System.out.println(streamOfNumbers.filter(i->i>6).count());
}
}
