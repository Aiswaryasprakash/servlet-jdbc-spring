package com.java8features;

interface Testpi1 {
public double getsum(int x,int y);
}
	
public class Testpi{
	public static void main(String[] args)
	{
		
		Testpi1 p=(x,y)->x+y;
		System.out.println("pi value is:"+p.getsum(10,20));
}}