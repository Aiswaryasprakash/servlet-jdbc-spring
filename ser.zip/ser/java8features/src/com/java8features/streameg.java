package com.java8features;

import java.util.ArrayList;
import java.util.List;

public class streameg {
public static void main(String[] args) {
	List<String> l=new ArrayList<String>();
	l.add("esf");
	l.add("esagw");
	l.add("esfsdg");
	
	long count=l.stream().filter(str->str.length()<6).count();
	System.out.println("there are  "+count+"  strings with length less than 6");
}
}
