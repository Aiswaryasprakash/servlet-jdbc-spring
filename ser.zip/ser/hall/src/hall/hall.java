package hall;
//import java.io.BufferedReader;
//import java.io.FileInputStream;
//import java.io.FileNotFoundException;
//import java.io.FileReader;
//import java.io.IOException;
//import java.io.InputStreamReader;
//import java.util.ArrayList;
//import java.util.Collections;
//import java.util.Comparator;
//import java.util.List;
//class hall {
//private String name;
//private double costpd;
//private int capacity;
//hall(String name,double costpd,int capacity)
//{
//	this.name=name;
//	this.costpd=costpd;
//	this.capacity=capacity;
//	
//	}
//public String getName() {
//	return name;
//}
//public void setName(String name) {
//	this.name = name;
//}
//public double getCostpd() {
//	return costpd;
//}
//public void setCostpd(double costpd) {
//	this.costpd = costpd;
//}
//public int getCapacity() {
//	return capacity;
//}
//public void setCapacity(int capacity) {
//	this.capacity = capacity;
//}
//
//	
//
//
//	public int compareTo(hall o1) {
//		double ctcomp=o1.getCostpd();
//	return (int) (ctcomp-this.costpd);
//		
//	}
//}
//
//package collection;
import java.util.*;
import java.lang.*;

public class hall{
private String name;
private double costperday;
private int capacity;

public hall(String name,double costperday,int capacity){
	this.name=name;
	this.costperday=costperday;
	this.capacity=capacity;
	
	}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public double getCostperday() {
	return costperday;
}

public void setCostperday(double costperday) {
	this.costperday = costperday;
}

public int getCapacity() {
	return capacity;
}

public void setCapacity(int capacity) {
	this.capacity = capacity;
}

@Override
public String toString() {
	return "hall [name=" + name + ", costperday=" + costperday + ", capacity=" + capacity + "]";
}}
class costcom  implements Comparator<hall>{

	@Override
	public int compare(hall o1, hall o2) {
	if(o1.getCostperday()==o2.getCostperday())
		return 0;
	else if(o1.getCostperday()>o2.getCostperday())
		return 1;
	else return -1;
	}

}


