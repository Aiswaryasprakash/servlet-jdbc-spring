package hall;
import java.util.*;
public class demohall {

	public static void main(String[] args) {

		
		
		
		
		
		
		Scanner sc=new Scanner(System.in);
		String s1=sc.nextLine();
		String s2=sc.nextLine();
		String s3=sc.nextLine();
		String a[]=new String[3];
		a=s1.split(",");
		String b[]=new String[3];
		b=s2.split(",");
		String c[]=new String[3];
		c=s3.split(",");
		
		
		ArrayList<hall>a1=new ArrayList<hall>();
		a1.add(new hall(a[0],Double.parseDouble(a[1]),Integer.parseInt(a[2])));
		a1.add(new hall(b[0],Double.parseDouble(b[1]),Integer.parseInt(b[2])));
		a1.add(new hall(c[0],Double.parseDouble(c[1]),Integer.parseInt(c[2])));
		Collections.sort(a1,new costcom());
		
		System.out.format("%-15s %-15s %s\n","name","costperday","capacity");
		
		for(hall st:a1){
			System.out.format("%-15s %-15s %s\n",st.getName(),st.getCostperday(),st.getCapacity());
		}
		
	}
	}
