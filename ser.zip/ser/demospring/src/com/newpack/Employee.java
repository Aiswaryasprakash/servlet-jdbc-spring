package com.newpack;

public class Employee {
int salary;
private Address addr;
//public Employee(){}
//
//public Employee(Address addr) {
//
//	this.addr = addr;
//}

public int getSalary() {
	return salary;
}

public void setSalary(int salary) {
	this.salary = salary;
}

public Address getAddr() {
	return addr;
}

public void setAddr(Address addr) {
	this.addr = addr;
}

@Override
public String toString() {
	return "Employee [salary=" + salary + ", addr=" + addr + "]";
}


}
