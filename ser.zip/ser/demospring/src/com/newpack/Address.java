package com.newpack;

public class Address {
int addrid;
String loc;
//public Address(int addrid, String loc) {
//	super();
//	this.addrid = addrid;
//	this.loc = loc;
//}
public int getAddrid() {
	return addrid;
}
public void setAddrid(int addrid) {
	this.addrid = addrid;
}
public String getLoc() {
	return loc;
}
public void setLoc(String loc) {
	this.loc = loc;
}
@Override
public String toString() {
	return "Address [addrid=" + addrid + ", loc=" + loc + "]";
}

}
