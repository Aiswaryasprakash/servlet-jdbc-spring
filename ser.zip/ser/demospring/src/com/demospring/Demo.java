package com.demospring;
import java.util.List;
import org.springframework.beans.factory.parsing.BeanDefinitionParsingException;

import org.springframework.context.ApplicationContext;


import org.springframework.context.support.ClassPathXmlApplicationContext;
public class Demo {

	public static void main(String[] args) {

ApplicationContext context=new ClassPathXmlApplicationContext("ApplicationContext.xml");

Book book=(Book)context.getBean("b");
List<String> l=book.getMob();
for(String s:l){
	System.out.println(s);

	}
	System.out.println(book.getMob());
	System.out.println(book.getBname());
	 
}}
