package com.demospring;

public class empdetails {

}
