package com.demospring;

import java.util.List;
import java.util.Set;

public class Book {
int id;
String bname;
List<String> mob;
public Book(int id, String bname, List<String> mob) {
	super();
	this.id = id;
	this.bname = bname;
	this.mob = mob;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getBname() {
	return bname;
}

public void setBname(String bname) {
	this.bname = bname;
}

public List<String> getMob() {
	return mob;
}

public void setMob(List<String> mob) {
	this.mob = mob;
}

@Override
public String toString() {
	return "Book [id=" + id + ", bname=" + bname + ", mob=" + mob + "]";
}

}