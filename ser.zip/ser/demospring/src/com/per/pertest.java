package com.per;
import org.springframework.context.ApplicationContext; 
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class pertest {
	public static void main(String[] args) {
		
Resource r=new ClassPathResource("appcontext.xml");
BeanFactory factory=new XmlBeanFactory(r);
perdemo obj=(perdemo) factory.getBean("pers");
System.out.println(obj);
}
}