package com.per;

public class person {
String name;
int id1;
@Override
public String toString() {
	return "person [name=" + name + ", id1=" + id1 + "]";
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getId() {
	return id1;
}
public void setId(int id1) {
	this.id1 = id1;
}
}
