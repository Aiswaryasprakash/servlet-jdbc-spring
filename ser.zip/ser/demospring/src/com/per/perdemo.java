package com.per;

public class perdemo {
person p;
int mob;

public int getMob() {
	return mob;
}

public void setMob(int mob) {
	this.mob = mob;
}

public person getP() {
	return p;
}

public void setP(person p) {
	this.p = p;
}

@Override
public String toString() {
	return "perdemo [p=" + p + ", mob=" + mob + "]";
}



}
