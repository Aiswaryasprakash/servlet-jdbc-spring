package aaspringcollection;
import org.springframework.context.ApplicationContext; 
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;


public class test {
	public static void main(String[] args) {
		Resource r=new ClassPathResource("AplicationContext.xml");
		BeanFactory f=new XmlBeanFactory(r);
		questions qst=(questions) f.getBean("q");
		qst.displayInfo();
	}
}
