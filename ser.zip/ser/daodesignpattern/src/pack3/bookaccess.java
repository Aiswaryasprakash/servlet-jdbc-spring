package pack3;

import daobooks.book;
import daodesignpattern.bookdaoimpl;
import model.books;

public class bookaccess {
public static void main(String[] args) {
	book bk=new bookdaoimpl();
	
	for(books bs:bk.getAllbooks()){
		System.out.println("id "+bs.getId()+"  name "+bs.getName());
	}
	
	books bs=bk.getAllbooks().get(0);
	bs.setName("dotnet");
	bk.updatebooks(bs);
	
	bk.getbooks(0);
	System.out.println("id "+bs.getId()+"  name "+bs.getName());
			
}
}
