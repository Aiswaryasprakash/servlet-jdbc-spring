package daodesignpattern;

import java.util.ArrayList;
import java.util.List;

import daobooks.book;
import model.books;

public class bookdaoimpl implements book{
 List<books> bss;
public bookdaoimpl(){
	bss=new ArrayList<books>();
	books bs1=new books(1,"java");
	books bs2=new books(2,"python");
	bss.add(bs1);
	bss.add(bs2);
	
	
}
@Override
public List<books> getAllbooks() {
	
	return bss;
}
@Override
public books getbooks(int id) {
	
	return bss.get(id);
}
@Override
public void updatebooks(books bs) {
	bss.get(bs.getId()).setName(bs.getName());
	System.out.println(bs.getId());
}
@Override
public void deletebooks(books bs) {
	bss.remove(bs.getId());
	System.out.println(bs.getId());
	
}
}