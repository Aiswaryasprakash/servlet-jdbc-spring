package daobooks;

import java.util.List;

import model.books;

public interface book {
public List<books>getAllbooks();
public books getbooks(int id);
public  void updatebooks(books bs);
public void deletebooks(books bs);
}
