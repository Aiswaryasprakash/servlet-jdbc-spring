package multithreading;


public class demo {

	public static void main(String[] args) {
	
			Thread t1= new testthread();
			Thread t2= new threadtest1();
			t1.setName("t1 thread");
			t1.start();
			t2.setName("t2 thread");
			t2.start();

			}
			

	}


