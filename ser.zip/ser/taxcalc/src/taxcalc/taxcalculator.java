

public class taxcalculator {
float basicsalary;
boolean citizenship;
void calculatetax()
{
	double tax=30*basicsalary/100;
	System.out.println("The Tax of the employee  for  the   "+basicsalary+" is "+tax);
}
void deducttax(){
	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
