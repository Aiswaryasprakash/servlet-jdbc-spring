import java.util.ArrayList;
import java.util.Collections;

public class sorting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<String> a1=new ArrayList();
a1.add("1");
a1.add("@");
a1.add("jik");
a1.add("jIk");
a1.add("sdfs");
a1.add("Zcv");

Collections.sort(a1);
System.out.println(a1);
	}

}
