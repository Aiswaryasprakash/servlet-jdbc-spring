package test;
import java.util.*;

import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.beans.Statement;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;   

//public static void main(String[] args) throws ParseException {
//	
//
//	SimpleDateFormat myFormat = new SimpleDateFormat("dd MM yyyy");
//	String s1 = "23 01 1997";
//	String s2 = "27 02 1997";
//
//	
//	    Date d1 = myFormat.parse(s1);
//	    Date d2 = myFormat.parse(s2);
//	   
//	        long l= ChronoUnit.MONTHS.between(d1.toInstant(), d2.toInstant());
//	        System.out.println(l);
//	    }
//}
//	   public static void main(String args[]){
//			 SimpleDateFormat sdf = new SimpleDateFormat("dd MM yyyy");
//			 String s1 = "31 01 2014";
//			 String s2 = "02 02 2014";

//			 try {
//			       Date d1 = sdf.parse(s1);
//			       Date d2 = sdf.parse(s2);
//			       long difference = d1.getTime() - d2.getTime();
//			       float days= (difference / (1000*60*60*24));
//		               /* You can also convert the milliseconds to days using this method
//		                * float daysBetween = 
//		                *         TimeUnit.DAYS.convert(difference, TimeUnit.MILLISECONDS)
//		                */
//			       System.out.println("Number of Days between dates: "+days);
//			 } catch (Exception e) {
//			       e.printStackTrace();
//			 }
//		   }
//		}
//			 
//			 public static void main(String[] args)
//			    {
//			        LocalDate d1 = LocalDate.of(2013, 01, 01);
//			        LocalDate d2 = LocalDate.of(2015, 08, 03);
//			 
//			        Period diff = Period.between(d1, d2);
//			 
//			     System.out.println(diff.getDays());
//			  }
//			}
	
public class test {  
public static void main(String[] args) {
	
try{
	Class.forName("com.mysql.jdbc.Driver");  
	
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Bookapp","root","root");
	Statement st=(Statement) con.createStatement();
	ResultSet rs=st.excuteQuery("select * from book");
	
	
	
}catch(IOException e)
{
	
	
	e.printStackTrace();
	
}
	
}