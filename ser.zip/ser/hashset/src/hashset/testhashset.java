package hashset;
import java.util.HashSet;
import java.util.TreeSet;

public class testhashset {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
TreeSet<String> h=new TreeSet();
h.add("sgfjh");
h.add("sfa");
h.add("sfa");
System.out.println(h);
	}

}
