package com.intro2;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




@WebServlet("/loginservlet1")
public class loginservlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public loginservlet1() {
        super();
       
    }

	

	protected boolean getDetails(String name, String pass) {
		boolean checker = false; 
		Connection con = null;
		PreparedStatement pre = null;
		try {
			String url="jdbc:mysql://localhost:3306/userreg";
			String user = "root";
			String password="Aspvpc@1";
			Class.forName("com.mysql.cj.jdbc.Driver");
			con =  DriverManager.getConnection(url, user, password);
			
			
			
			String sql = "select * from user where name=? and pass=?";
			pre = con.prepareStatement(sql);
			
			pre.setString(1, name);
			pre.setString(2, pass);
			
			ResultSet re = pre.executeQuery();
			
			checker=re.next();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				pre.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		
		return checker;
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		RequestDispatcher rd = null;
		PrintWriter write = response.getWriter();
		
		String name1 = request.getParameter("name");
		String pass1 = request.getParameter("pass");
		
		System.out.println(name1+" "+pass1);
	
		
		
		
		if(getDetails(name1,pass1)) {
			rd = request.getRequestDispatcher("/welcomeservlet");
			rd.forward(request, response);
		}
		else {
			rd = request.getRequestDispatcher("login.html");
			write.println("Sorry  Your  " + name1 + "  and  Password  were  wrong") ;
			rd.include(request, response);
	}

	}}
